<?php
    echo "Bienvenido a PHP";
?>
