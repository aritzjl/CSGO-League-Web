<?php
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    echo "Tu navegador es: $user_agent";
?>
